package com.example.dobokocka_jatek;


import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {




    int pontszamlalo1_field = 0;
    int pontszamlalo2_field = 0;
    int dobas1_field = 0;
    int dobas2_field = 0;
    boolean gameOver1 = false;
    boolean gameOver2 = false;
    boolean lost1 = false;
    boolean lost2 = false;
    TextView jatekos_nevek;
    Button jatekButton, dobasButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        jatekButton = findViewById(R.id.jatek_gomb);
        Random random = new Random();
        EditText j1 = findViewById(R.id.jatekos1);
        EditText j2 = findViewById(R.id.jatekos2);
        TextView j1_dobasai = findViewById(R.id.jatekos1_dobasai);
        TextView j2_dobasai = findViewById(R.id.jatekos2_dobasai);

        Runnable checkWinner = () -> {
            if (gameOver1 && gameOver2) {
                TextView eredmeny = findViewById(R.id.eredmeny);
                eredmeny.setVisibility(View.VISIBLE);

                if (lost1 && lost2) {
                    eredmeny.setText("Mindkét játékos kiesett!");
                } else if (lost1 && !lost2) {
                    eredmeny.setText("2. játékos nyert!");
                } else if (lost2 && !lost1) {
                    eredmeny.setText("1. játékos nyert!");
                } else if (pontszamlalo1_field > pontszamlalo2_field) {
                    eredmeny.setText("1. játékos nyert!");
                } else if (pontszamlalo2_field > pontszamlalo1_field) {
                    eredmeny.setText("2. játékos nyert!");
                } else {
                    eredmeny.setText("Döntetlen!");
                }
            }
        };

        TextView leiras = findViewById(R.id.jatek_leiras);

        Button jatszok = findViewById(R.id.jatszok_gomb);
        Button dobj1 = findViewById(R.id.dobj1);
        Button dobj2 = findViewById(R.id.dobj2);
        Button uj_jatek = findViewById(R.id.uj_jatek);



        leiras.setVisibility(View.GONE);
        j1.setVisibility(View.GONE);
        j2.setVisibility(View.GONE);
        jatekButton.setVisibility(View.GONE);
        dobj1.setVisibility(View.GONE);
        dobj2.setVisibility(View.GONE);
        j1_dobasai.setVisibility(View.GONE);
        j2_dobasai.setVisibility(View.GONE);
        uj_jatek.setVisibility(View.GONE);


        jatszok.setOnClickListener(v->{
            leiras.setVisibility(View.VISIBLE);
            j1.setVisibility(View.VISIBLE);
            j2.setVisibility(View.VISIBLE);
            jatekButton.setVisibility(View.VISIBLE);
            dobj1.setVisibility(View.GONE);
            dobj2.setVisibility(View.GONE);
            jatszok.setVisibility(View.GONE);
        });


        jatekButton.setOnClickListener(v->{
            leiras.setVisibility(View.GONE);
            dobj1.setVisibility(View.VISIBLE);
            dobj2.setVisibility(View.VISIBLE);
            jatekButton.setVisibility(View.GONE);
            j1_dobasai.setVisibility(View.VISIBLE);
            j2_dobasai.setVisibility(View.VISIBLE);

        });




        dobj1.setOnClickListener(v->{

            if (gameOver1) return;

            dobas1_field++;
            int randomSzam1 = random.nextInt(6) + 1;
            j1_dobasai.setText("Dobás: " + randomSzam1);

            if (randomSzam1 == 3) {
                dobj1.setVisibility(View.GONE);
                j1_dobasai.setText("Vesztettél!");
                gameOver1 = true;
                lost1 = true;
                checkWinner.run();
                return;
            }

            pontszamlalo1_field += randomSzam1;

            if (dobas1_field >= 5) {
                dobj1.setVisibility(View.GONE);
                j1_dobasai.setText("A játék véget ért. A pontjaid összege: " + pontszamlalo1_field);
                gameOver1 = true;
                checkWinner.run();
            }
        });

        dobj2.setOnClickListener(v->{
            if (gameOver2) return;

            dobas2_field++;
            int randomSzam2 = random.nextInt(6) + 1;
            j2_dobasai.setText("Dobás: " + randomSzam2);

            if (randomSzam2 == 3) {
                dobj2.setVisibility(View.GONE);
                j2_dobasai.setText("Vesztettél!");
                gameOver2 = true;
                lost2 = true;
                checkWinner.run();
                return;
            }

            pontszamlalo2_field += randomSzam2;

            if (dobas2_field >= 5) {
                dobj2.setVisibility(View.GONE);
                j2_dobasai.setText("A játék véget ért. A pontjaid összege: " + pontszamlalo2_field);
                gameOver2 = true;
                checkWinner.run();
            }
        });
        TextView eredmeny = findViewById(R.id.eredmeny);

        eredmeny.setVisibility(View.GONE);









        uj_jatek.setOnClickListener(v->{

        });















    }




}